/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.animal;

public interface FlyingAnimal {
    public boolean isFlying();
}

