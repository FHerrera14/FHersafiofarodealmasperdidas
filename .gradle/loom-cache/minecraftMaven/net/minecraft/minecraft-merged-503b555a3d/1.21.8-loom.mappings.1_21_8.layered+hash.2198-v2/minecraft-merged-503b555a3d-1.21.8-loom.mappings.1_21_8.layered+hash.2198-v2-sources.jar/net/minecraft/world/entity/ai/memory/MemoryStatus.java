/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.ai.memory;

public enum MemoryStatus {
    VALUE_PRESENT,
    VALUE_ABSENT,
    REGISTERED;

}

