/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.ai.util;

import com.google.common.annotations.VisibleForTesting;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.ToDoubleFunction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class RandomPos {
    private static final int RANDOM_POS_ATTEMPTS = 10;

    public static BlockPos generateRandomDirection(RandomSource randomSource, int i, int j) {
        int k = randomSource.nextInt(2 * i + 1) - i;
        int l = randomSource.nextInt(2 * j + 1) - j;
        int m = randomSource.nextInt(2 * i + 1) - i;
        return new BlockPos(k, l, m);
    }

    @Nullable
    public static BlockPos generateRandomDirectionWithinRadians(RandomSource randomSource, int i, int j, int k, double d, double e, double f) {
        double g = Mth.atan2(e, d) - 1.5707963705062866;
        double h = g + (double)(2.0f * randomSource.nextFloat() - 1.0f) * f;
        double l = Math.sqrt(randomSource.nextDouble()) * (double)Mth.SQRT_OF_TWO * (double)i;
        double m = -l * Math.sin(h);
        double n = l * Math.cos(h);
        if (Math.abs(m) > (double)i || Math.abs(n) > (double)i) {
            return null;
        }
        int o = randomSource.nextInt(2 * j + 1) - j + k;
        return BlockPos.containing(m, o, n);
    }

    @VisibleForTesting
    public static BlockPos moveUpOutOfSolid(BlockPos blockPos, int i, Predicate<BlockPos> predicate) {
        if (predicate.test(blockPos)) {
            BlockPos.MutableBlockPos mutableBlockPos = blockPos.mutable().move(Direction.UP);
            while (mutableBlockPos.getY() <= i && predicate.test(mutableBlockPos)) {
                mutableBlockPos.move(Direction.UP);
            }
            return mutableBlockPos.immutable();
        }
        return blockPos;
    }

    @VisibleForTesting
    public static BlockPos moveUpToAboveSolid(BlockPos blockPos, int i, int j, Predicate<BlockPos> predicate) {
        if (i < 0) {
            throw new IllegalArgumentException("aboveSolidAmount was " + i + ", expected >= 0");
        }
        if (predicate.test(blockPos)) {
            BlockPos.MutableBlockPos mutableBlockPos = blockPos.mutable().move(Direction.UP);
            while (mutableBlockPos.getY() <= j && predicate.test(mutableBlockPos)) {
                mutableBlockPos.move(Direction.UP);
            }
            int k = mutableBlockPos.getY();
            while (mutableBlockPos.getY() <= j && mutableBlockPos.getY() - k < i) {
                mutableBlockPos.move(Direction.UP);
                if (!predicate.test(mutableBlockPos)) continue;
                mutableBlockPos.move(Direction.DOWN);
                break;
            }
            return mutableBlockPos.immutable();
        }
        return blockPos;
    }

    @Nullable
    public static Vec3 generateRandomPos(PathfinderMob pathfinderMob, Supplier<BlockPos> supplier) {
        return RandomPos.generateRandomPos(supplier, pathfinderMob::getWalkTargetValue);
    }

    @Nullable
    public static Vec3 generateRandomPos(Supplier<BlockPos> supplier, ToDoubleFunction<BlockPos> toDoubleFunction) {
        double d = Double.NEGATIVE_INFINITY;
        BlockPos blockPos = null;
        for (int i = 0; i < 10; ++i) {
            double e;
            BlockPos blockPos2 = supplier.get();
            if (blockPos2 == null || !((e = toDoubleFunction.applyAsDouble(blockPos2)) > d)) continue;
            d = e;
            blockPos = blockPos2;
        }
        return blockPos != null ? Vec3.atBottomCenterOf(blockPos) : null;
    }

    public static BlockPos generateRandomPosTowardDirection(PathfinderMob pathfinderMob, int i, RandomSource randomSource, BlockPos blockPos) {
        int j = blockPos.getX();
        int k = blockPos.getZ();
        if (pathfinderMob.hasHome() && i > 1) {
            BlockPos blockPos2 = pathfinderMob.getHomePosition();
            j = pathfinderMob.getX() > (double)blockPos2.getX() ? (j -= randomSource.nextInt(i / 2)) : (j += randomSource.nextInt(i / 2));
            k = pathfinderMob.getZ() > (double)blockPos2.getZ() ? (k -= randomSource.nextInt(i / 2)) : (k += randomSource.nextInt(i / 2));
        }
        return BlockPos.containing((double)j + pathfinderMob.getX(), (double)blockPos.getY() + pathfinderMob.getY(), (double)k + pathfinderMob.getZ());
    }
}

