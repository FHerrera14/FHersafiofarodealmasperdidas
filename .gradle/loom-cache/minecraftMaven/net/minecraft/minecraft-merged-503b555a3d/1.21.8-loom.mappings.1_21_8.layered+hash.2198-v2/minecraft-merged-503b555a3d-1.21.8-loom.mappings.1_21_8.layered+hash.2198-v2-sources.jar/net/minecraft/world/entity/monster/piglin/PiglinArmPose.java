/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.monster.piglin;

public enum PiglinArmPose {
    ATTACKING_WITH_MELEE_WEAPON,
    CROSSBOW_HOLD,
    CROSSBOW_CHARGE,
    ADMIRING_ITEM,
    DANCING,
    DEFAULT;

}

