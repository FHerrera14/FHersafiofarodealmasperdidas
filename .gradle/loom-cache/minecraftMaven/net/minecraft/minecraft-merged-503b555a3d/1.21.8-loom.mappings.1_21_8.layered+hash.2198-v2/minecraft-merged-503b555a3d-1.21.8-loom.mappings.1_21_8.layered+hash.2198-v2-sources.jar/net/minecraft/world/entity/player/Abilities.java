/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.player;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class Abilities {
    private static final boolean DEFAULT_INVULNERABLE = false;
    private static final boolean DEFAULY_FLYING = false;
    private static final boolean DEFAULT_MAY_FLY = false;
    private static final boolean DEFAULT_INSTABUILD = false;
    private static final boolean DEFAULT_MAY_BUILD = true;
    private static final float DEFAULT_FLYING_SPEED = 0.05f;
    private static final float DEFAULT_WALKING_SPEED = 0.1f;
    public boolean invulnerable;
    public boolean flying;
    public boolean mayfly;
    public boolean instabuild;
    public boolean mayBuild = true;
    private float flyingSpeed = 0.05f;
    private float walkingSpeed = 0.1f;

    public float getFlyingSpeed() {
        return this.flyingSpeed;
    }

    public void setFlyingSpeed(float f) {
        this.flyingSpeed = f;
    }

    public float getWalkingSpeed() {
        return this.walkingSpeed;
    }

    public void setWalkingSpeed(float f) {
        this.walkingSpeed = f;
    }

    public Packed pack() {
        return new Packed(this.invulnerable, this.flying, this.mayfly, this.instabuild, this.mayBuild, this.flyingSpeed, this.walkingSpeed);
    }

    public void apply(Packed packed) {
        this.invulnerable = packed.invulnerable;
        this.flying = packed.flying;
        this.mayfly = packed.mayFly;
        this.instabuild = packed.instabuild;
        this.mayBuild = packed.mayBuild;
        this.flyingSpeed = packed.flyingSpeed;
        this.walkingSpeed = packed.walkingSpeed;
    }

    public record Packed(boolean invulnerable, boolean flying, boolean mayFly, boolean instabuild, boolean mayBuild, float flyingSpeed, float walkingSpeed) {
        public static final Codec<Packed> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Codec.BOOL.fieldOf("invulnerable")).orElse(false).forGetter(Packed::invulnerable), ((MapCodec)Codec.BOOL.fieldOf("flying")).orElse(false).forGetter(Packed::flying), ((MapCodec)Codec.BOOL.fieldOf("mayfly")).orElse(false).forGetter(Packed::mayFly), ((MapCodec)Codec.BOOL.fieldOf("instabuild")).orElse(false).forGetter(Packed::instabuild), ((MapCodec)Codec.BOOL.fieldOf("mayBuild")).orElse(true).forGetter(Packed::mayBuild), ((MapCodec)Codec.FLOAT.fieldOf("flySpeed")).orElse(Float.valueOf(0.05f)).forGetter(Packed::flyingSpeed), ((MapCodec)Codec.FLOAT.fieldOf("walkSpeed")).orElse(Float.valueOf(0.1f)).forGetter(Packed::walkingSpeed)).apply((Applicative<Packed, ?>)instance, Packed::new));
    }
}

