/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.server;

import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.datafixers.DataFixer;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.Lifecycle;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.Proxy;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import joptsimple.AbstractOptionSpec;
import joptsimple.ArgumentAcceptingOptionSpec;
import joptsimple.NonOptionArgumentSpec;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpecBuilder;
import joptsimple.util.PathConverter;
import joptsimple.util.PathProperties;
import net.minecraft.CrashReport;
import net.minecraft.DefaultUncaughtExceptionHandler;
import net.minecraft.SharedConstants;
import net.minecraft.SuppressForbidden;
import net.minecraft.Util;
import net.minecraft.commands.Commands;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTestTicker;
import net.minecraft.nbt.NbtException;
import net.minecraft.nbt.ReportedNbtException;
import net.minecraft.network.chat.Component;
import net.minecraft.obfuscate.DontObfuscate;
import net.minecraft.server.Bootstrap;
import net.minecraft.server.Eula;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.Services;
import net.minecraft.server.WorldLoader;
import net.minecraft.server.WorldStem;
import net.minecraft.server.dedicated.DedicatedServer;
import net.minecraft.server.dedicated.DedicatedServerProperties;
import net.minecraft.server.dedicated.DedicatedServerSettings;
import net.minecraft.server.level.progress.LoggerChunkProgressListener;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.repository.ServerPacksSource;
import net.minecraft.util.Mth;
import net.minecraft.util.datafix.DataFixers;
import net.minecraft.util.profiling.jfr.Environment;
import net.minecraft.util.profiling.jfr.JvmProfiler;
import net.minecraft.util.worldupdate.WorldUpgrader;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.chunk.storage.RegionFileVersion;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.WorldDimensions;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.level.storage.LevelDataAndDimensions;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.LevelSummary;
import net.minecraft.world.level.storage.PrimaryLevelData;
import net.minecraft.world.level.storage.WorldData;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class Main {
    private static final Logger LOGGER = LogUtils.getLogger();

    @SuppressForbidden(reason="System.out needed before bootstrap")
    @DontObfuscate
    public static void main(String[] strings) {
        SharedConstants.tryDetectVersion();
        OptionParser optionParser = new OptionParser();
        OptionSpecBuilder optionSpec = optionParser.accepts("nogui");
        OptionSpecBuilder optionSpec2 = optionParser.accepts("initSettings", "Initializes 'server.properties' and 'eula.txt', then quits");
        OptionSpecBuilder optionSpec3 = optionParser.accepts("demo");
        OptionSpecBuilder optionSpec4 = optionParser.accepts("bonusChest");
        OptionSpecBuilder optionSpec5 = optionParser.accepts("forceUpgrade");
        OptionSpecBuilder optionSpec6 = optionParser.accepts("eraseCache");
        OptionSpecBuilder optionSpec7 = optionParser.accepts("recreateRegionFiles");
        OptionSpecBuilder optionSpec8 = optionParser.accepts("safeMode", "Loads level with vanilla datapack only");
        AbstractOptionSpec optionSpec9 = optionParser.accepts("help").forHelp();
        ArgumentAcceptingOptionSpec<String> optionSpec10 = optionParser.accepts("universe").withRequiredArg().defaultsTo(".", (String[])new String[0]);
        ArgumentAcceptingOptionSpec<String> optionSpec11 = optionParser.accepts("world").withRequiredArg();
        ArgumentAcceptingOptionSpec<Integer> optionSpec12 = optionParser.accepts("port").withRequiredArg().ofType(Integer.class).defaultsTo(-1, (Integer[])new Integer[0]);
        ArgumentAcceptingOptionSpec<String> optionSpec13 = optionParser.accepts("serverId").withRequiredArg();
        OptionSpecBuilder optionSpec14 = optionParser.accepts("jfrProfile");
        ArgumentAcceptingOptionSpec<Path> optionSpec15 = optionParser.accepts("pidFile").withRequiredArg().withValuesConvertedBy(new PathConverter(new PathProperties[0]));
        NonOptionArgumentSpec<String> optionSpec16 = optionParser.nonOptions();
        try {
            WorldStem worldStem;
            Dynamic<?> dynamic;
            OptionSet optionSet = optionParser.parse(strings);
            if (optionSet.has(optionSpec9)) {
                optionParser.printHelpOn(System.err);
                return;
            }
            Path path = optionSet.valueOf(optionSpec15);
            if (path != null) {
                Main.writePidFile(path);
            }
            CrashReport.preload();
            if (optionSet.has(optionSpec14)) {
                JvmProfiler.INSTANCE.start(Environment.SERVER);
            }
            Bootstrap.bootStrap();
            Bootstrap.validate();
            Util.startTimerHackThread();
            Path path2 = Paths.get("server.properties", new String[0]);
            DedicatedServerSettings dedicatedServerSettings = new DedicatedServerSettings(path2);
            dedicatedServerSettings.forceSave();
            RegionFileVersion.configure(dedicatedServerSettings.getProperties().regionFileComression);
            Path path3 = Paths.get("eula.txt", new String[0]);
            Eula eula = new Eula(path3);
            if (optionSet.has(optionSpec2)) {
                LOGGER.info("Initialized '{}' and '{}'", (Object)path2.toAbsolutePath(), (Object)path3.toAbsolutePath());
                return;
            }
            if (!eula.hasAgreedToEULA()) {
                LOGGER.info("You need to agree to the EULA in order to run the server. Go to eula.txt for more info.");
                return;
            }
            File file = new File(optionSet.valueOf(optionSpec10));
            Services services = Services.create(new YggdrasilAuthenticationService(Proxy.NO_PROXY), file);
            String string = Optional.ofNullable(optionSet.valueOf(optionSpec11)).orElse(dedicatedServerSettings.getProperties().levelName);
            LevelStorageSource levelStorageSource = LevelStorageSource.createDefault(file.toPath());
            LevelStorageSource.LevelStorageAccess levelStorageAccess = levelStorageSource.validateAndCreateAccess(string);
            if (levelStorageAccess.hasWorldData()) {
                LevelSummary levelSummary;
                try {
                    dynamic = levelStorageAccess.getDataTag();
                    levelSummary = levelStorageAccess.getSummary(dynamic);
                } catch (IOException | NbtException | ReportedNbtException exception) {
                    LevelStorageSource.LevelDirectory levelDirectory = levelStorageAccess.getLevelDirectory();
                    LOGGER.warn("Failed to load world data from {}", (Object)levelDirectory.dataFile(), (Object)exception);
                    LOGGER.info("Attempting to use fallback");
                    try {
                        dynamic = levelStorageAccess.getDataTagFallback();
                        levelSummary = levelStorageAccess.getSummary(dynamic);
                    } catch (IOException | NbtException | ReportedNbtException exception2) {
                        LOGGER.error("Failed to load world data from {}", (Object)levelDirectory.oldDataFile(), (Object)exception2);
                        LOGGER.error("Failed to load world data from {} and {}. World files may be corrupted. Shutting down.", (Object)levelDirectory.dataFile(), (Object)levelDirectory.oldDataFile());
                        return;
                    }
                    levelStorageAccess.restoreLevelDataFromOld();
                }
                if (levelSummary.requiresManualConversion()) {
                    LOGGER.info("This world must be opened in an older version (like 1.6.4) to be safely converted");
                    return;
                }
                if (!levelSummary.isCompatible()) {
                    LOGGER.info("This world was created by an incompatible version.");
                    return;
                }
            } else {
                dynamic = null;
            }
            Dynamic<?> dynamic2 = dynamic;
            boolean bl = optionSet.has(optionSpec8);
            if (bl) {
                LOGGER.warn("Safe mode active, only vanilla datapack will be loaded");
            }
            PackRepository packRepository = ServerPacksSource.createPackRepository(levelStorageAccess);
            try {
                WorldLoader.InitConfig initConfig = Main.loadOrCreateConfig(dedicatedServerSettings.getProperties(), dynamic2, bl, packRepository);
                worldStem = (WorldStem)Util.blockUntilDone(executor -> WorldLoader.load(initConfig, dataLoadContext -> {
                    WorldDimensions worldDimensions;
                    WorldOptions worldOptions;
                    LevelSettings levelSettings;
                    HolderLookup.RegistryLookup registry = dataLoadContext.datapackDimensions().lookupOrThrow(Registries.LEVEL_STEM);
                    if (dynamic2 != null) {
                        LevelDataAndDimensions levelDataAndDimensions = LevelStorageSource.getLevelDataAndDimensions(dynamic2, dataLoadContext.dataConfiguration(), (Registry<LevelStem>)registry, dataLoadContext.datapackWorldgen());
                        return new WorldLoader.DataLoadOutput<WorldData>(levelDataAndDimensions.worldData(), levelDataAndDimensions.dimensions().dimensionsRegistryAccess());
                    }
                    LOGGER.info("No existing world data, creating new world");
                    if (optionSet.has(optionSpec3)) {
                        levelSettings = MinecraftServer.DEMO_SETTINGS;
                        worldOptions = WorldOptions.DEMO_OPTIONS;
                        worldDimensions = WorldPresets.createNormalWorldDimensions(dataLoadContext.datapackWorldgen());
                    } else {
                        DedicatedServerProperties dedicatedServerProperties = dedicatedServerSettings.getProperties();
                        levelSettings = new LevelSettings(dedicatedServerProperties.levelName, dedicatedServerProperties.gamemode, dedicatedServerProperties.hardcore, dedicatedServerProperties.difficulty, false, new GameRules(dataLoadContext.dataConfiguration().enabledFeatures()), dataLoadContext.dataConfiguration());
                        worldOptions = optionSet.has(optionSpec4) ? dedicatedServerProperties.worldOptions.withBonusChest(true) : dedicatedServerProperties.worldOptions;
                        worldDimensions = dedicatedServerProperties.createDimensions(dataLoadContext.datapackWorldgen());
                    }
                    WorldDimensions.Complete complete = worldDimensions.bake((Registry<LevelStem>)registry);
                    Lifecycle lifecycle = complete.lifecycle().add(dataLoadContext.datapackWorldgen().allRegistriesLifecycle());
                    return new WorldLoader.DataLoadOutput<PrimaryLevelData>(new PrimaryLevelData(levelSettings, worldOptions, complete.specialWorldProperty(), lifecycle), complete.dimensionsRegistryAccess());
                }, WorldStem::new, Util.backgroundExecutor(), executor)).get();
            } catch (Exception exception3) {
                LOGGER.warn("Failed to load datapacks, can't proceed with server load. You can either fix your datapacks or reset to vanilla with --safeMode", exception3);
                return;
            }
            RegistryAccess.Frozen frozen = worldStem.registries().compositeAccess();
            WorldData worldData = worldStem.worldData();
            boolean bl2 = optionSet.has(optionSpec7);
            if (optionSet.has(optionSpec5) || bl2) {
                Main.forceUpgrade(levelStorageAccess, worldData, DataFixers.getDataFixer(), optionSet.has(optionSpec6), () -> true, frozen, bl2);
            }
            levelStorageAccess.saveDataTag(frozen, worldData);
            final DedicatedServer dedicatedServer = MinecraftServer.spin(thread -> {
                boolean bl;
                DedicatedServer dedicatedServer = new DedicatedServer((Thread)thread, levelStorageAccess, packRepository, worldStem, dedicatedServerSettings, DataFixers.getDataFixer(), services, LoggerChunkProgressListener::createFromGameruleRadius);
                dedicatedServer.setPort((Integer)optionSet.valueOf(optionSpec12));
                dedicatedServer.setDemo(optionSet.has(optionSpec3));
                dedicatedServer.setId((String)optionSet.valueOf(optionSpec13));
                boolean bl2 = bl = !optionSet.has(optionSpec) && !optionSet.valuesOf(optionSpec16).contains("nogui");
                if (bl && !GraphicsEnvironment.isHeadless()) {
                    dedicatedServer.showGui();
                }
                GameTestTicker.SINGLETON.startTicking();
                return dedicatedServer;
            });
            Thread thread2 = new Thread("Server Shutdown Thread"){

                @Override
                public void run() {
                    dedicatedServer.halt(true);
                }
            };
            thread2.setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(LOGGER));
            Runtime.getRuntime().addShutdownHook(thread2);
        } catch (Exception exception4) {
            LOGGER.error(LogUtils.FATAL_MARKER, "Failed to start the minecraft server", exception4);
        }
    }

    private static void writePidFile(Path path) {
        try {
            long l = ProcessHandle.current().pid();
            Files.writeString(path, (CharSequence)Long.toString(l), new OpenOption[0]);
        } catch (IOException iOException) {
            throw new UncheckedIOException(iOException);
        }
    }

    private static WorldLoader.InitConfig loadOrCreateConfig(DedicatedServerProperties dedicatedServerProperties, @Nullable Dynamic<?> dynamic, boolean bl, PackRepository packRepository) {
        WorldDataConfiguration worldDataConfiguration2;
        boolean bl2;
        if (dynamic != null) {
            WorldDataConfiguration worldDataConfiguration = LevelStorageSource.readDataConfig(dynamic);
            bl2 = false;
            worldDataConfiguration2 = worldDataConfiguration;
        } else {
            bl2 = true;
            worldDataConfiguration2 = new WorldDataConfiguration(dedicatedServerProperties.initialDataPackConfiguration, FeatureFlags.DEFAULT_FLAGS);
        }
        WorldLoader.PackConfig packConfig = new WorldLoader.PackConfig(packRepository, worldDataConfiguration2, bl, bl2);
        return new WorldLoader.InitConfig(packConfig, Commands.CommandSelection.DEDICATED, dedicatedServerProperties.functionPermissionLevel);
    }

    private static void forceUpgrade(LevelStorageSource.LevelStorageAccess levelStorageAccess, WorldData worldData, DataFixer dataFixer, boolean bl, BooleanSupplier booleanSupplier, RegistryAccess registryAccess, boolean bl2) {
        LOGGER.info("Forcing world upgrade!");
        try (WorldUpgrader worldUpgrader = new WorldUpgrader(levelStorageAccess, dataFixer, worldData, registryAccess, bl, bl2);){
            Component component = null;
            while (!worldUpgrader.isFinished()) {
                int i;
                Component component2 = worldUpgrader.getStatus();
                if (component != component2) {
                    component = component2;
                    LOGGER.info(worldUpgrader.getStatus().getString());
                }
                if ((i = worldUpgrader.getTotalChunks()) > 0) {
                    int j = worldUpgrader.getConverted() + worldUpgrader.getSkipped();
                    LOGGER.info("{}% completed ({} / {} chunks)...", Mth.floor((float)j / (float)i * 100.0f), j, i);
                }
                if (!booleanSupplier.getAsBoolean()) {
                    worldUpgrader.cancel();
                    continue;
                }
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException interruptedException) {}
            }
        }
    }
}

