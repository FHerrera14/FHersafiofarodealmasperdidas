/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.monster;

public interface Enemy {
    public static final int XP_REWARD_NONE = 0;
    public static final int XP_REWARD_SMALL = 3;
    public static final int XP_REWARD_MEDIUM = 5;
    public static final int XP_REWARD_LARGE = 10;
    public static final int XP_REWARD_HUGE = 20;
    public static final int XP_REWARD_BOSS = 50;
}

