/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.world.entity.npc;

import net.minecraft.world.entity.npc.VillagerData;

public interface VillagerDataHolder {
    public VillagerData getVillagerData();

    public void setVillagerData(VillagerData var1);
}

