/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.fhersafio.farodealmasperdidas.init;

import java.util.function.Function;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import com.fhersafio.farodealmasperdidas.block.FaroDeAlmasBlock;
import com.fhersafio.farodealmasperdidas.FhersafioFaroDeAlmasPerdidasMod;

public class FhersafioFaroDeAlmasPerdidasModBlocks {
	public static class_2248 FARO_DE_ALMAS;

	public static void load() {
		FARO_DE_ALMAS = register("faro_de_almas", FaroDeAlmasBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends class_2248> B register(String name, Function<class_4970.class_2251, B> supplier) {
		return (B) class_2246.method_63053(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(FhersafioFaroDeAlmasPerdidasMod.MODID, name)), (Function<class_4970.class_2251, class_2248>) supplier, class_4970.class_2251.method_9637());
	}
}