/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.fhersafio.farodealmasperdidas.init;

import com.fhersafio.farodealmasperdidas.FhersafioFaroDeAlmasPerdidasMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class FhersafioFaroDeAlmasPerdidasModSounds {
	public static class_3414 BREAK_FARO;
	public static class_3414 PLACE_FARO;
	public static class_3414 DROP_FARO;
	public static class_3414 PLAYER_DEAD;
	public static class_3414 PLAYER_REVIVE;
	public static class_3414 FIRST_GEM_MISSION;
	public static class_3414 SECOND_GEM_MISSION;
	public static class_3414 THIRD_GEM_MISSION;
	public static class_3414 FOUR_GEM_MISSION_FINAL_BOSS;
	public static class_3414 VILLAGE_MISSION;

	public static void load() {
		BREAK_FARO = register("break_faro", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "break_faro")));
		PLACE_FARO = register("place_faro", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "place_faro")));
		DROP_FARO = register("drop_faro", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "drop_faro")));
		PLAYER_DEAD = register("player_dead", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "player_dead")));
		PLAYER_REVIVE = register("player_revive", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "player_revive")));
		FIRST_GEM_MISSION = register("first_gem_mission", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "first_gem_mission")));
		SECOND_GEM_MISSION = register("second_gem_mission", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "second_gem_mission")));
		THIRD_GEM_MISSION = register("third_gem_mission", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "third_gem_mission")));
		FOUR_GEM_MISSION_FINAL_BOSS = register("four_gem_mission_final_boss", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "four_gem_mission_final_boss")));
		VILLAGE_MISSION = register("village_mission", class_3414.method_47908(class_2960.method_60655("fhersafio_faro_de_almas_perdidas", "village_mission")));
	}

	private static class_3414 register(String registryname, class_3414 element) {
		return class_2378.method_10230(class_7923.field_41172, class_2960.method_60655(FhersafioFaroDeAlmasPerdidasMod.MODID, registryname), element);
	}
}