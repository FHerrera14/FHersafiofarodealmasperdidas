/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.fhersafio.farodealmasperdidas.init;

import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import com.fhersafio.farodealmasperdidas.item.*;
import com.fhersafio.farodealmasperdidas.FhersafioFaroDeAlmasPerdidasMod;

public class FhersafioFaroDeAlmasPerdidasModItems {
	public static class_1792 FARO_DE_ALMAS;
	public static class_1792 CUCHARA_RESURECCION;
	public static class_1792 TENEDOR_DE_LA_VIDA;
	public static class_1792 VARA_DE_ALMAS;
	public static class_1792 NACATAMAL;
	public static class_1792 CARNE_ASADA;
	public static class_1792 PAN_SEMITA;
	public static class_1792 BIG_COLITA;

	public static void load() {
		FARO_DE_ALMAS = block(FhersafioFaroDeAlmasPerdidasModBlocks.FARO_DE_ALMAS, "faro_de_almas", new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904));
		CUCHARA_RESURECCION = register("cuchara_resureccion", CucharaResureccionItem::new);
		TENEDOR_DE_LA_VIDA = register("tenedor_de_la_vida", TenedorDeLaVidaItem::new);
		VARA_DE_ALMAS = register("vara_de_almas", VaraDeAlmasItem::new);
		NACATAMAL = register("nacatamal", NacatamalItem::new);
		CARNE_ASADA = register("carne_asada", CarneAsadaItem::new);
		PAN_SEMITA = register("pan_semita", PanSemitaItem::new);
		BIG_COLITA = register("big_colita", BigColitaItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends class_1792> I register(String name, Function<class_1792.class_1793, ? extends I> supplier) {
		return (I) class_1802.method_63747(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(FhersafioFaroDeAlmasPerdidasMod.MODID, name)), (Function<class_1792.class_1793, class_1792>) supplier);
	}

	private static class_1792 block(class_2248 block, String name) {
		return block(block, name, new class_1792.class_1793());
	}

	private static class_1792 block(class_2248 block, String name, class_1792.class_1793 properties) {
		return class_1802.method_51348(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(FhersafioFaroDeAlmasPerdidasMod.MODID, name)), prop -> new class_1747(block, prop), properties);
	}
}