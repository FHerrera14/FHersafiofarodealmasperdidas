/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.fhersafio.farodealmasperdidas.init;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import com.fhersafio.farodealmasperdidas.FhersafioFaroDeAlmasPerdidasMod;

public class FhersafioFaroDeAlmasPerdidasModTabs {
	public static class_5321<class_1761> TAB_TAB_F_HERSAFIO = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(FhersafioFaroDeAlmasPerdidasMod.MODID, "tab_f_hersafio"));

	public static void load() {
		class_2378.method_39197(class_7923.field_44687, TAB_TAB_F_HERSAFIO, FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group.fhersafio_faro_de_almas_perdidas.tab_f_hersafio"))
				.method_47320(() -> new class_1799(FhersafioFaroDeAlmasPerdidasModBlocks.FARO_DE_ALMAS)).method_47317((parameters, tabData) -> {
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModBlocks.FARO_DE_ALMAS.method_8389());
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.CUCHARA_RESURECCION);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.TENEDOR_DE_LA_VIDA);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.VARA_DE_ALMAS);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.NACATAMAL);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.CARNE_ASADA);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.PAN_SEMITA);
					tabData.method_45421(FhersafioFaroDeAlmasPerdidasModItems.BIG_COLITA);
				}).method_47324());
	}
}