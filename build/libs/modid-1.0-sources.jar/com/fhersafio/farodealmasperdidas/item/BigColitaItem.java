package com.fhersafio.farodealmasperdidas.item;

import com.fhersafio.farodealmasperdidas.procedures.BigColitaAlJugadorDejarDeUsarloProcedure;
import net.minecraft.class_10128;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_4174;

public class BigColitaItem extends class_1792 {
	public BigColitaItem(class_1792.class_1793 properties) {
		super(properties.method_7894(class_1814.field_8904).method_7889(6).method_24359().method_62833((new class_4174.class_4175()).method_19238(5).method_19237(20f).method_19242(), class_10128.field_53780));
	}

	@Override
	public boolean method_7840(class_1799 itemstack, class_1937 world, class_1309 entity, int time) {
		BigColitaAlJugadorDejarDeUsarloProcedure.execute(entity);
		return super.method_7840(itemstack, world, entity, time);
	}
}