package com.fhersafio.farodealmasperdidas.item;

import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;

public class VaraDeAlmasItem extends class_1792 {
	public VaraDeAlmasItem(class_1792.class_1793 properties) {
		super(properties.method_7894(class_1814.field_8904).method_7895(24).method_24359()
				.method_57348(class_9285.method_57480().method_57487(class_5134.field_23721, new class_1322(field_8006, -1, class_1322.class_1323.field_6328), class_9274.field_49217)
						.method_57487(class_5134.field_23723, new class_1322(field_8001, -2.4, class_1322.class_1323.field_6328), class_9274.field_49217).method_57486()));
	}

	@Override
	public boolean method_7886(class_1799 itemstack) {
		return true;
	}

	@Override
	public void method_7873(class_1799 itemstack, class_1309 entity, class_1309 sourceentity) {
		itemstack.method_7970(1, entity, class_1309.method_56079(entity.method_6058()));
	}
}