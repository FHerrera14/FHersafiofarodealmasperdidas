package com.fhersafio.farodealmasperdidas.item;

import com.fhersafio.farodealmasperdidas.procedures.PanSemitaAlJugadorDejarDeUsarloProcedure;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_4174;

public class PanSemitaItem extends class_1792 {
	public PanSemitaItem(class_1792.class_1793 properties) {
		super(properties.method_7894(class_1814.field_8903).method_7889(12).method_19265((new class_4174.class_4175()).method_19238(5).method_19237(5f).method_19242()));
	}

	@Override
	public boolean method_7840(class_1799 itemstack, class_1937 world, class_1309 entity, int time) {
		PanSemitaAlJugadorDejarDeUsarloProcedure.execute(entity);
		return super.method_7840(itemstack, world, entity, time);
	}
}