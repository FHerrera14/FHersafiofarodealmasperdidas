package com.fhersafio.farodealmasperdidas.block;

import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import com.fhersafio.farodealmasperdidas.init.FhersafioFaroDeAlmasPerdidasModBlocks;

public class FaroDeAlmasBlock extends class_2248 {
	public FaroDeAlmasBlock(class_4970.class_2251 properties) {
		super(properties.method_9626(new class_2498(1.0f, 1.0f, null, null, null, null, null) {
			@Override
			public class_3414 method_10595() {
				return class_7923.field_41172.method_63535(class_2960.method_60654("fhersafio_faro_de_almas_perdidas:break_faro"));
			}

			@Override
			public class_3414 method_10594() {
				return class_7923.field_41172.method_63535(class_2960.method_60654("block.amethyst_block.step"));
			}

			@Override
			public class_3414 method_10598() {
				return class_7923.field_41172.method_63535(class_2960.method_60654("fhersafio_faro_de_almas_perdidas:place_faro"));
			}

			@Override
			public class_3414 method_10596() {
				return class_7923.field_41172.method_63535(class_2960.method_60654("block.amethyst_block.hit"));
			}

			@Override
			public class_3414 method_10593() {
				return class_7923.field_41172.method_63535(class_2960.method_60654("fhersafio_faro_de_almas_perdidas:drop_faro"));
			}
		}).method_9629(-1, 3600000).method_9631(s -> 15).method_22488().method_26247((bs, br, bp) -> true).method_26249((bs, br, bp) -> true).method_26236((bs, br, bp) -> false));
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(FhersafioFaroDeAlmasPerdidasModBlocks.FARO_DE_ALMAS, class_11515.field_60926);
	}

	@Override
	public boolean method_9579(class_2680 state) {
		return true;
	}

	@Override
	public int method_9505(class_2680 state) {
		return 0;
	}

	@Override
	public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return class_259.method_1073();
	}
}