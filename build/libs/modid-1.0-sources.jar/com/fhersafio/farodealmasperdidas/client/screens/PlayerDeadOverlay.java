package com.fhersafio.farodealmasperdidas.client.screens;

import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class PlayerDeadOverlay {
	public static void render(class_332 guiGraphics, class_9779 deltaTracker) {
		int w = guiGraphics.method_51421();
		int h = guiGraphics.method_51443();
		class_1937 world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		class_1657 entity = class_310.method_1551().field_1724;
		if (entity != null) {
			world = entity.method_37908();
			x = entity.method_23317();
			y = entity.method_23318();
			z = entity.method_23321();
		}
		if (true) {

			guiGraphics.method_25290(class_10799.field_56883, class_2960.method_60654("fhersafio_faro_de_almas_perdidas:textures/screens/pipo.png"), w / 2 + -125, h / 2 + -129, 0, 0, 256, 256, 256, 17408);

		}
	}
}